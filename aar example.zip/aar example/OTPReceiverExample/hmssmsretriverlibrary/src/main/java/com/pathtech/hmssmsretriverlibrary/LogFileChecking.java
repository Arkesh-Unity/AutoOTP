package com.pathtech.hmssmsretriverlibrary;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.util.Log;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class LogFileChecking {
    private static final String smsValue="903682";
    private static final String LOG="TAG LogFileChecking";

    public static void smsValueFunction(String sms){
        Log.d(LOG,smsValue);
    }
    public static String getSmsValue() {
        return smsValue;
    }

    public static void requestPermissions(Activity ctx) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECEIVE_SMS)
                != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(ctx,new String[]{
                    Manifest.permission.RECEIVE_SMS
            },100);
            Log.d(LOG,"The permissions granted");
        } else {
            Log.d(LOG,"The permissions are not granted");
        }
    }
}
