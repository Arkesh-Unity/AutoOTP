package com.pathtech.hmssmsretriverlibrary;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.IntentService;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.Iterator;
import java.util.List;


/**
 * An {@link IntentService} subclass for handling asynchronous task requests in
 * a service on a separate handler thread.
 * <p>
 * TODO: Customize class - update intent actions and extra parameters.
 */
public class ServiceCommunication extends Service {
    // TODO: Rename actions, choose action names that describe tasks that this
    // IntentService can perform, e.g. ACTION_FETCH_NEW_ITEMS
    public static final String ACTION_FOO = "com.example.otpreceiverexample.action.FOO";
    public static final String ACTION_BAZ = "com.example.otpreceiverexample.action.BAZ";

    // TODO: Rename parameters
    public static final String EXTRA_PARAM1 = "com.example.otpreceiverexample.extra.PARAM1";
    public static final String EXTRA_PARAM2 = "com.example.otpreceiverexample.extra.PARAM2";

    private static final String LOG="TAG ServiceCommunication";

    public ServiceCommunication()
    {      }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @SuppressLint("LongLogTag")
    @Override
    public void onCreate()
    {
        super.onCreate();
        Log.d(LOG,"onCreate ");
        Toast.makeText(this, "Service Created", Toast.LENGTH_LONG).show();

        ActivityManager manager = (ActivityManager) this.getSystemService(Context.ACTIVITY_SERVICE);

        List<ActivityManager.RunningAppProcessInfo> tasks = manager.getRunningAppProcesses();

        Log.e("current_app",tasks.get(0).processName);






    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {


        Toast.makeText(this, "Start Command", Toast.LENGTH_LONG).show();


        ActivityManager m = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE );
        List<ActivityManager.RunningTaskInfo> runningTaskInfoList =  m.getRunningTasks(10);
        Iterator<ActivityManager.RunningTaskInfo> itr = runningTaskInfoList.iterator();
        while(itr.hasNext())
        {
            ActivityManager.RunningTaskInfo runningTaskInfo = (ActivityManager.RunningTaskInfo)itr.next();
            int id = runningTaskInfo.id;
            CharSequence desc= runningTaskInfo.description;
            String topActivity = runningTaskInfo.topActivity.getShortClassName();
            int numOfActivities = runningTaskInfo.numActivities;

            Log.e("Activity Name",topActivity);
        }

        return super.onStartCommand(intent, flags, startId);

      //  return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    /*    @Override
    protected void onHandleIntent(Intent intent) {
        if (intent != null) {
            final String action = intent.getAction();
            if (ACTION_FOO.equals(action)) {
                final String param1 = intent.getStringExtra(EXTRA_PARAM1);
                final String param2 = intent.getStringExtra(EXTRA_PARAM2);
                handleActionFoo(param1, param2);
            } else if (ACTION_BAZ.equals(action)) {
                final String param1 = intent.getStringExtra(EXTRA_PARAM1);
                final String param2 = intent.getStringExtra(EXTRA_PARAM2);
                handleActionBaz(param1, param2);
            }
        }
    }

    *//**
     * Handle action Foo in the provided background thread with the provided
     * parameters.
     *//*
    private void handleActionFoo(String param1, String param2) {
        // TODO: Handle action Foo
        throw new UnsupportedOperationException("Not yet implemented");
    }

    *//**
     * Handle action Baz in the provided background thread with the provided
     * parameters.
     *//*
    private void handleActionBaz(String param1, String param2) {
        // TODO: Handle action Baz
        throw new UnsupportedOperationException("Not yet implemented");
    }*/
}
