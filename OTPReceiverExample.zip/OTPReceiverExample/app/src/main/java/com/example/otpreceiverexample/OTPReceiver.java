package com.example.otpreceiverexample;

import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

import static android.content.Context.ACTIVITY_SERVICE;
import static com.example.otpreceiverexample.MainActivity.activityManager;
import static java.lang.Runtime.getRuntime;

public class OTPReceiver extends BroadcastReceiver {

    private static EditText editText_otp;

    public void setEditText_otp(EditText editText){
        OTPReceiver.editText_otp = editText;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void onReceive(Context context, Intent intent) {
        SmsMessage[] smsMessages = Telephony.Sms.Intents.getMessagesFromIntent(intent);
        try {
            for (SmsMessage smsMessage : smsMessages) {
                String message_body = smsMessage.getMessageBody();
                String getOTP1 = message_body.split(" ")[0];
                String getOTP = message_body.split(" ")[1];
                Toast. makeText(context,getOTP,Toast. LENGTH_SHORT).show();
                List<ActivityManager.RunningAppProcessInfo> appProcesses = activityManager.getRunningAppProcesses();
                for(ActivityManager.RunningAppProcessInfo appProcess : appProcesses){
                    if(appProcess.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND){
                        Log.i("Foreground App", appProcess.processName);
                        Toast. makeText(context,"Foreground :" + appProcess.processName,Toast. LENGTH_SHORT).show();
                    }
                }
                editText_otp.setText(getOTP);

            }
        }catch (Exception e){
            for (SmsMessage smsMessage : smsMessages) {
                String message_body = smsMessage.getMessageBody();
                String getOTP1 = message_body.split(":")[0];
                String getOTP = message_body.split(":")[1];
                editText_otp.setText(getOTP);
                Toast. makeText(context,getOTP,Toast. LENGTH_SHORT).show();
            }
        }
    }
}
