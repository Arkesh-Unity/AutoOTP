package com.example.otpreceiverexample;

import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import java.util.List;

import static android.content.Context.ACTIVITY_SERVICE;
import static java.lang.Runtime.getRuntime;

public class OTPReceiver extends BroadcastReceiver
{

    private static EditText editText_otp;

    private static String TAG = "Test Value";

    public void setEditText_otp(EditText editText){
        OTPReceiver.editText_otp = editText;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void onReceive(Context context, Intent intent)
    {
        SmsMessage[] smsMessages = Telephony.Sms.Intents.getMessagesFromIntent(intent);
        try {
            for (SmsMessage smsMessage : smsMessages) {
                String message_body = smsMessage.getMessageBody();
                String getOTP1 = message_body.split(" ")[0];
                String getOTP = message_body.split(" ")[1];
                Toast. makeText(context,getOTP,Toast. LENGTH_SHORT).show();

             /*   Process process Runtime.getRuntime().exec("/system/bin/mv my_file_path");
                Process  process Runtime.getRuntime().exec("adb shell dumpsys activity");
                BufferedReader bufferedReader = new BufferedReader(
                        new InputStreamReader(process.getInputStream()));*/
                // editText_otp.setText(getOTP);

                Toast.makeText(context,"OTP Receiver",Toast.LENGTH_SHORT).show();

                ActivityManager mngr = (ActivityManager) context.getSystemService( ACTIVITY_SERVICE );

                List<ActivityManager.RunningTaskInfo> taskList = mngr.getRunningTasks(10);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(new Intent(context,ServiceCommunication.class));
                }

                if(taskList.get(0).numActivities == 1 &&
                        taskList.get(0).topActivity.getClassName().equals(this.getClass().getName()))
                {
                    Log.i(TAG, "This is last activity in the stack");
                    Toast.makeText(context,"Test User",Toast.LENGTH_SHORT).show();
                }

            }
        }catch (Exception e)
        {
            for (SmsMessage smsMessage : smsMessages) {
                String message_body = smsMessage.getMessageBody();
                String getOTP1 = message_body.split(":")[0];
                String getOTP = message_body.split(":")[1];
                editText_otp.setText(getOTP);
            }
        }
    }

}
